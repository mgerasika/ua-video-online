"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENV = void 0;
exports.ENV = {
    user: process.env.DB_USER,
    host: '178.210.131.101',
    database: 'ua-video-torrent',
    password: process.env.DB_PASSWORD,
    port: 5432,
};
