"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var serverless_http_1 = __importDefault(require("serverless-http"));
var express_app_1 = require("../express-app");
var db_service_1 = require("../controller/db.service");
var api_url_constant_1 = require("../constants/api-url.constant");
express_app_1.app.get('/echo', function (req, res) {
    res.send('echo ');
});
console.log('load all express apis', db_service_1.dbService);
express_app_1.app.get('/', function (req, res) {
    res.send('/' + JSON.stringify(api_url_constant_1.API_URL, null, 2));
});
exports.handler = (0, serverless_http_1.default)(express_app_1.app);
