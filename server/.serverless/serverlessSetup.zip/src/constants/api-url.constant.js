"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.API_URL = void 0;
var react_create_url_1 = require("react-create-url");
exports.API_URL = (0, react_create_url_1.createUrls)({
    swagger: react_create_url_1.EMPTY_URL_ITEM,
    api: {
        user: {
            id: function (id) { return react_create_url_1.EMPTY_URL_ITEM; },
        },
        imdb: {
            id: function (id) { return react_create_url_1.EMPTY_URL_ITEM; },
        },
        movie: {
            search: react_create_url_1.EMPTY_URL_ITEM,
            groupSearch: {
                id: function (id) { return react_create_url_1.EMPTY_URL_ITEM; },
            },
            id: function (id) { return react_create_url_1.EMPTY_URL_ITEM; },
        },
        tools: {
            getHurtomAll: react_create_url_1.EMPTY_URL_ITEM,
            setup: react_create_url_1.EMPTY_URL_ITEM,
            searchImdbInfo: react_create_url_1.EMPTY_URL_ITEM,
        },
        s3: {
            get: {
                id: function (id) { return ({
                    hasFile: react_create_url_1.EMPTY_URL_ITEM,
                }); },
            },
            upload: react_create_url_1.EMPTY_URL_ITEM,
        },
    },
});
